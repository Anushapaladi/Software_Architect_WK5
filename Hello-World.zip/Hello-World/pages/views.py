# this is only responsible for views

'''
and
actually
responsile
for pae
stucture
'''
from django.http import HttpResponse
import json
# http and json objects are being imported
def homePageView(request):
    #ckunhj kjhgya
    data = {
        "message" : "Hello World!"
    }
    #ckunhj kjhgya#ckunhj kjhgya
    dump = json.dumps(data)

    #ckunhj kjhgya
    #njokiggv sciugdi 
    return HttpResponse(dump, content_type='application/json')
'''change code here to

chnge the op
displayed on
web page
'''
